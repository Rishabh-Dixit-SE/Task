module.exports = {
    theme: {
      extend: {
        colors: {
          primary: '#3498db',
          secondary: '#f1c40f',
        },
      },
    },
  }